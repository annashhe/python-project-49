### Hexlet tests and linter status:
[![Actions Status](https://github.com/annashhe/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/annashhe/python-project-49/actions)
<a href="https://codeclimate.com/github/annashhe/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/381f426c0a0eea131cc6/maintainability" /></a>
<a href="https://codeclimate.com/github/annashhe/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/381f426c0a0eea131cc6/test_coverage" /></a>

asciinema

brain-even
<a href="https://asciinema.org/a/0Ufs1whbYtN5la9uFZHYoQv9Y" target="_blank"><img src="https://asciinema.org/a/0Ufs1whbYtN5la9uFZHYoQv9Y.svg" /></a>

brain-calc
[![asciicast](https://asciinema.org/a/Nr0yX4ghQau9yM0vOqFXrvKFJ.svg)](https://asciinema.org/a/Nr0yX4ghQau9yM0vOqFXrvKFJ)