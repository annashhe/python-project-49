### Hexlet tests and linter status:
[![Actions Status](https://github.com/annashhe/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/annashhe/python-project-49/actions)
<a href="https://codeclimate.com/github/annashhe/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/381f426c0a0eea131cc6/maintainability" /></a>
<a href="https://codeclimate.com/github/annashhe/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/381f426c0a0eea131cc6/test_coverage" /></a>